import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Plus,
  Minus,
  Timer,
  Clock,
  Flag,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { sound } from '../utils/audio';
import { Team } from '../types';

interface DualTimerProps {
  teamA?: Team;
  teamB?: Team;
  isStandalone?: boolean;
}

export const DualTimer: React.FC<DualTimerProps> = ({
  teamA,
  teamB,
  isStandalone = false,
}) => {
  // Countdown Timer State
  const [countdownInitial, setCountdownInitial] = useState<number>(60);
  const [countdownLeft, setCountdownLeft] = useState<number>(60);
  const [countdownActive, setCountdownActive] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Stopwatch State
  const [stopwatchMs, setStopwatchMs] = useState<number>(0);
  const [stopwatchActive, setStopwatchActive] = useState<boolean>(false);
  const [teamATime, setTeamATime] = useState<string | null>(null);
  const [teamBTime, setTeamBTime] = useState<string | null>(null);

  // Fullscreen state
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Countdown Interval Ref
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (countdownActive && countdownLeft > 0) {
      interval = setInterval(() => {
        setCountdownLeft((prev) => {
          if (prev <= 1) {
            // Reached zero!
            if (soundEnabled) {
              sound.playBuzzer();
            }
            setCountdownActive(false);
            return 0;
          }
          if (prev <= 6 && prev > 1 && soundEnabled) {
            sound.playWarningBeep();
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [countdownActive, countdownLeft, soundEnabled]);

  // Stopwatch Interval Ref
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (stopwatchActive) {
      const startTime = Date.now() - stopwatchMs;
      interval = setInterval(() => {
        setStopwatchMs(Date.now() - startTime);
      }, 33); // ~30 fps update for crisp centiseconds
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [stopwatchActive, stopwatchMs]);

  // Format countdown mm:ss
  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Format stopwatch mm:ss.cc
  const formatStopwatch = (ms: number) => {
    const mins = Math.floor(ms / 60000);
    const secs = Math.floor((ms % 60000) / 1000);
    const centis = Math.floor((ms % 1000) / 10);
    return {
      main: `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`,
      sub: `.${String(centis).padStart(2, '0')}`,
    };
  };

  // Countdown Quick Presets
  const setPreset = (sec: number) => {
    sound.playTick();
    setCountdownActive(false);
    setCountdownInitial(sec);
    setCountdownLeft(sec);
  };

  const adjustCountdown = (delta: number) => {
    sound.playTick();
    setCountdownLeft((prev) => Math.max(0, prev + delta));
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  const swFormatted = formatStopwatch(stopwatchMs);

  return (
    <div
      ref={containerRef}
      className={`w-full ${
        isStandalone ? 'min-h-screen bg-[#070B19] p-4 sm:p-8' : ''
      }`}
    >
      {/* Standalone Header if opened in secondary window */}
      {isStandalone && (
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center font-bold text-white font-changa text-lg shadow-lg">
              5
            </div>
            <div>
              <h1 className="text-xl font-bold font-changa text-white">
                دوري التحدي 5 - واجهة الموقّت الميداني المستقلة
              </h1>
              <p className="text-xs text-slate-400">
                مؤقت تنازلي بصافرة رقمية وساعة إيقاف لحساب أجزاء الثانية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2.5 rounded-xl border transition-colors ${
                soundEnabled
                  ? 'bg-purple-950/60 border-purple-500/60 text-purple-300'
                  : 'bg-slate-800 border-slate-700 text-slate-500'
              }`}
              title={soundEnabled ? 'كتم الصوت' : 'تفعيل صوت الصافرة'}
            >
              {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>

            <button
              onClick={toggleFullscreen}
              className="p-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="ملء الشاشة"
            >
              {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </button>
          </div>
        </div>
      )}

      {/* DUAL TIMERS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. COUNTDOWN TIMER CARD */}
        <div className="bg-[#0C1226]/90 border border-slate-800/90 rounded-3xl p-5 sm:p-8 shadow-2xl relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-purple-400">
              <Timer className="w-6 h-6" />
              <h2 className="text-lg font-bold font-changa text-white">
                المؤقت التنازلي (Countdown)
              </h2>
            </div>

            <div className="flex items-center gap-1.5">
              {!isStandalone && (
                <button
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className={`p-2 rounded-lg border text-xs transition-colors ${
                    soundEnabled
                      ? 'bg-purple-950/50 border-purple-700 text-purple-300'
                      : 'bg-slate-800 border-slate-700 text-slate-500'
                  }`}
                >
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>
              )}
            </div>
          </div>

          {/* Big Digital Display */}
          <div className="my-6 text-center">
            <div
              className={`font-orbitron font-black text-6xl sm:text-8xl md:text-9xl tracking-wider py-6 px-4 rounded-3xl border-2 transition-all ${
                countdownLeft <= 5 && countdownLeft > 0
                  ? 'bg-rose-950/40 border-rose-500 text-rose-400 shadow-[0_0_50px_rgba(244,63,94,0.4)] animate-pulse'
                  : countdownLeft === 0
                  ? 'bg-red-950/60 border-red-500 text-red-500 shadow-[0_0_60px_rgba(239,68,68,0.6)]'
                  : 'bg-[#050814] border-purple-900/60 text-purple-200 shadow-[0_0_40px_rgba(168,85,247,0.25)]'
              }`}
            >
              {formatCountdown(countdownLeft)}
            </div>

            {countdownLeft === 0 && (
              <div className="mt-3 text-red-400 font-bold font-changa text-base sm:text-lg animate-bounce">
                انتهى الوقت! (TIME OUT)
              </div>
            )}
          </div>

          {/* Quick Preset Buttons */}
          <div className="mb-6">
            <div className="text-xs text-slate-400 font-semibold mb-2 text-right">
              الأوقات السريعة الجاهزة:
            </div>
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {[
                { label: '15ث', sec: 15 },
                { label: '30ث', sec: 30 },
                { label: '45ث', sec: 45 },
                { label: '1د (60ث)', sec: 60 },
                { label: '90ث', sec: 90 },
                { label: '2د', sec: 120 },
                { label: '3د', sec: 180 },
                { label: '5د', sec: 300 },
              ].map((p) => (
                <button
                  key={p.sec}
                  onClick={() => setPreset(p.sec)}
                  className={`py-2 px-1 text-xs font-bold rounded-xl border transition-all ${
                    countdownInitial === p.sec && !countdownActive
                      ? 'bg-purple-600 text-white border-purple-400 shadow-md shadow-purple-600/30'
                      : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Large Field Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {/* Start / Pause Big Button */}
            <button
              onClick={() => {
                sound.playTick();
                setCountdownActive(!countdownActive);
              }}
              className={`w-full flex-1 py-4 sm:py-5 px-6 rounded-2xl font-bold font-changa text-lg sm:text-xl flex items-center justify-center gap-3 transition-all shadow-xl active:scale-95 ${
                countdownActive
                  ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/30'
                  : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-600/40'
              }`}
            >
              {countdownActive ? (
                <>
                  <Pause className="w-6 h-6 fill-white" />
                  <span>إيقاف مؤقت</span>
                </>
              ) : (
                <>
                  <Play className="w-6 h-6 fill-white" />
                  <span>بدء العداد التنازلي</span>
                </>
              )}
            </button>

            {/* Stepper + / - 10s */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => adjustCountdown(-10)}
                className="flex-1 sm:flex-initial py-3.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-1 transition-colors"
                title="خصم 10 ثوانٍ"
              >
                <Minus className="w-4 h-4" />
                <span>10ث</span>
              </button>
              <button
                onClick={() => adjustCountdown(10)}
                className="flex-1 sm:flex-initial py-3.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-1 transition-colors"
                title="إضافة 10 ثوانٍ"
              >
                <Plus className="w-4 h-4" />
                <span>10ث</span>
              </button>

              {/* Reset */}
              <button
                onClick={() => {
                  sound.playTick();
                  setCountdownActive(false);
                  setCountdownLeft(countdownInitial);
                }}
                className="p-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors"
                title="إعادة ضبط العداد"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* 2. STOPWATCH / COUNT-UP CARD */}
        <div className="bg-[#0C1226]/90 border border-slate-800/90 rounded-3xl p-5 sm:p-8 shadow-2xl relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-cyan-400">
              <Clock className="w-6 h-6" />
              <h2 className="text-lg font-bold font-changa text-white">
                ساعة الإيقاف التصاعدية (Stopwatch)
              </h2>
            </div>
            <span className="text-xs text-slate-400 font-mono">دقة أجزاء الثانية</span>
          </div>

          {/* Big Digital Display with centiseconds */}
          <div className="my-6 text-center">
            <div className="bg-[#050814] border-2 border-cyan-900/60 text-cyan-300 py-6 px-4 rounded-3xl shadow-[0_0_40px_rgba(6,182,212,0.25)] flex items-baseline justify-center font-orbitron font-black">
              <span className="text-6xl sm:text-8xl md:text-9xl tracking-wider">
                {swFormatted.main}
              </span>
              <span className="text-3xl sm:text-5xl md:text-6xl text-cyan-400/70 ml-1">
                {swFormatted.sub}
              </span>
            </div>
          </div>

          {/* Record Team Times for Time-Based Challenges */}
          <div className="mb-6 bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800">
            <div className="text-xs text-slate-400 font-semibold mb-2.5 flex items-center justify-between">
              <span>تسجيل زمن إنجاز الفرق للتحدي:</span>
              <span className="text-[11px] text-slate-500">لحسم الفائز بالأسرع وقتاً</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Team A Record */}
              <div className="flex flex-col gap-1.5 p-2.5 rounded-xl bg-purple-950/20 border border-purple-900/40">
                <div className="flex items-center justify-between text-xs text-purple-300 font-bold">
                  <span>{teamA?.name || 'الفريق الأول'}</span>
                  {teamATime && (
                    <span className="font-mono text-white text-sm bg-purple-900/50 px-2 py-0.5 rounded">
                      {teamATime}
                    </span>
                  )}
                </div>
                <button
                  onClick={() => {
                    sound.playTick();
                    setTeamATime(`${swFormatted.main}${swFormatted.sub}`);
                  }}
                  className="py-1.5 px-2 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>تثبيت وقت {teamA?.shortName || 'فريق 1'}</span>
                </button>
              </div>

              {/* Team B Record */}
              <div className="flex flex-col gap-1.5 p-2.5 rounded-xl bg-cyan-950/20 border border-cyan-900/40">
                <div className="flex items-center justify-between text-xs text-cyan-300 font-bold">
                  <span>{teamB?.name || 'الفريق الثاني'}</span>
                  {teamBTime && (
                    <span className="font-mono text-white text-sm bg-cyan-900/50 px-2 py-0.5 rounded">
                      {teamBTime}
                    </span>
                  )}
                </div>
                <button
                  onClick={() => {
                    sound.playTick();
                    setTeamBTime(`${swFormatted.main}${swFormatted.sub}`);
                  }}
                  className="py-1.5 px-2 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-200 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>تثبيت وقت {teamB?.shortName || 'فريق 2'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Large Field Controls for Stopwatch */}
          <div className="flex items-center gap-3">
            {/* Start / Pause */}
            <button
              onClick={() => {
                sound.playTick();
                setStopwatchActive(!stopwatchActive);
              }}
              className={`flex-1 py-4 sm:py-5 px-6 rounded-2xl font-bold font-changa text-lg sm:text-xl flex items-center justify-center gap-3 transition-all shadow-xl active:scale-95 ${
                stopwatchActive
                  ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/30'
                  : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-cyan-600/40'
              }`}
            >
              {stopwatchActive ? (
                <>
                  <Pause className="w-6 h-6 fill-white" />
                  <span>إيقاف الساعة</span>
                </>
              ) : (
                <>
                  <Play className="w-6 h-6 fill-white" />
                  <span>بدء ساعة الإيقاف</span>
                </>
              )}
            </button>

            {/* Reset */}
            <button
              onClick={() => {
                sound.playTick();
                setStopwatchActive(false);
                setStopwatchMs(0);
              }}
              className="py-4 sm:py-5 px-5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors"
              title="تصفير ساعة الإيقاف"
            >
              <RotateCcw className="w-6 h-6" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
