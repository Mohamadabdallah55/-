import React, { useState, useEffect } from 'react';
import { CurrentMatch, Team, GameItem, LeagueRow, CategoryInfo } from '../types';
import { GameIcon } from './GameIcons';
import { Trophy, Maximize2, Minimize2, Timer, Clock } from 'lucide-react';

interface BroadcastOverlayProps {
  currentMatch: CurrentMatch;
  teams: Team[];
  games: GameItem[];
  standings: LeagueRow[];
  categories: CategoryInfo[];
  onClose: () => void;
}

export const BroadcastOverlay: React.FC<BroadcastOverlayProps> = ({
  currentMatch,
  teams,
  games,
  standings,
  categories,
  onClose,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const teamA = teams.find((t) => t.id === currentMatch.teamAId) || teams[0];
  const teamB = teams.find((t) => t.id === currentMatch.teamBId) || teams[1] || teams[0];
  const activeGame = games.find((g) => g.id === currentMatch.activeGameId);
  const activeCategory = activeGame ? categories.find((c) => c.id === activeGame.categoryId) : null;

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#050814] text-white flex flex-col justify-between p-6 md:p-10 select-none overflow-hidden">
      {/* Top TV Header Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 flex items-center justify-center font-changa font-black text-2xl text-white shadow-lg shadow-purple-500/30">
            5
          </div>
          <div>
            <h1 className="text-2xl font-black font-changa tracking-wide uppercase text-white">
              دوري التحدي 5 · LIVE BROADCAST
            </h1>
            <p className="text-xs text-slate-400 font-mono tracking-wider">
              OFFICIAL ARENA SCOREBOARD
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={toggleFullscreen}
            className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 transition-colors"
            title="ملء الشاشة"
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
          >
            الخروج من وضع البث
          </button>
        </div>
      </div>

      {/* Main Broadcast Center Stage */}
      <div className="my-auto max-w-5xl mx-auto w-full">
        {/* Active Game Spotlight */}
        {activeGame && (
          <div className="text-center mb-6 animate-fade-in">
            <span className="text-xs uppercase tracking-widest text-cyan-400 font-mono bg-cyan-950/50 border border-cyan-800/80 px-4 py-1 rounded-full">
              {activeCategory?.nameAr} · {activeGame.nameEn}
            </span>
            <h2 className="text-3xl md:text-5xl font-black font-changa text-white mt-2 drop-shadow-lg">
              {activeGame.nameAr}
            </h2>
          </div>
        )}

        {/* Big Match Score Bar (Matching Screenshot 2026-09-23 at 7.04.21 AM) */}
        <div className="bg-[#070B19] rounded-3xl border-2 border-slate-700 shadow-[0_15px_50px_rgba(0,0,0,0.9)] p-4 md:p-6 flex items-center justify-between gap-6 relative">
          
          {/* Team A */}
          <div className="flex items-center gap-6">
            <div
              className="w-24 h-24 md:w-32 md:h-32 rounded-3xl flex items-center justify-center text-5xl md:text-7xl font-black font-orbitron text-white shadow-2xl"
              style={{
                backgroundColor: teamA?.color || '#A855F7',
                boxShadow: `0 0 30px ${teamA?.color || '#A855F7'}70`,
              }}
            >
              {currentMatch.teamAScore}
            </div>

            <div className="text-right">
              <h3 className="text-2xl md:text-4xl font-black font-changa text-white uppercase tracking-wider">
                {teamA?.shortName || teamA?.name}
              </h3>
              <p className="text-sm text-purple-300 font-medium">{teamA?.name}</p>
            </div>
          </div>

          {/* Center Emblem */}
          <div className="flex flex-col items-center">
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 p-0.5 shadow-[0_0_35px_rgba(99,102,241,0.6)]">
              <div className="w-full h-full bg-[#070B19] rounded-[14px] flex items-center justify-center">
                <GameIcon
                  name={activeGame?.iconType || 'trophy'}
                  className="w-10 h-10 md:w-12 md:h-12 text-cyan-300"
                />
              </div>
            </div>
            <span className="mt-2 text-xs font-mono uppercase tracking-widest text-slate-400">
              FIRST TO 3
            </span>
          </div>

          {/* Team B */}
          <div className="flex items-center gap-6">
            <div className="text-left">
              <h3 className="text-2xl md:text-4xl font-black font-changa text-white uppercase tracking-wider">
                {teamB?.shortName || teamB?.name}
              </h3>
              <p className="text-sm text-cyan-300 font-medium">{teamB?.name}</p>
            </div>

            <div
              className="w-24 h-24 md:w-32 md:h-32 rounded-3xl flex items-center justify-center text-5xl md:text-7xl font-black font-orbitron text-white shadow-2xl"
              style={{
                backgroundColor: teamB?.color || '#06B6D4',
                boxShadow: `0 0 30px ${teamB?.color || '#06B6D4'}70`,
              }}
            >
              {currentMatch.teamBScore}
            </div>
          </div>
        </div>

        {/* Best of 5 Rounds Track */}
        <div className="flex items-center justify-center gap-3 mt-4">
          {[1, 2, 3, 4, 5].map((roundNum) => {
            const totalRoundsPlayed = currentMatch.teamAScore + currentMatch.teamBScore;
            const isWonByA = roundNum <= currentMatch.teamAScore;
            const isWonByB = roundNum > currentMatch.teamAScore && roundNum <= totalRoundsPlayed;
            const isCurrent = roundNum === totalRoundsPlayed + 1 && currentMatch.teamAScore < 3 && currentMatch.teamBScore < 3;

            return (
              <div
                key={roundNum}
                className={`px-5 py-2 rounded-xl text-sm font-bold font-changa flex items-center gap-2 ${
                  isWonByA
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/50'
                    : isWonByB
                    ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/50'
                    : isCurrent
                    ? 'bg-slate-800 text-amber-300 border-2 border-amber-400 animate-pulse'
                    : 'bg-slate-900/90 text-slate-600 border border-slate-800'
                }`}
              >
                <span>الجولة {roundNum}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Leaderboard Strip */}
      <div className="bg-[#0C1226]/80 rounded-2xl p-4 border border-slate-800/80">
        <div className="text-xs text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          <span>ترتيب دوري التحدي المباشر:</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {standings.map((row, idx) => (
            <div
              key={row.teamId}
              className="p-2 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-2">
                <span className="font-mono text-slate-500 font-bold">#{idx + 1}</span>
                <span className="font-bold text-white font-changa">{row.team.shortName}</span>
              </div>
              <span className="font-orbitron font-extrabold text-amber-400">{row.points} PTS</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
