import {
  CurrentMatch,
  MatchRecord,
  Team,
  LeagueRow,
  CategoryKey,
  CardState,
  GameItem,
  DualTimerSyncState,
} from '../types';
import { INITIAL_TEAMS, DEFAULT_GAMES } from '../data/defaultGames';

const STORAGE_KEYS = {
  TEAMS: 'tahadi5_teams_v1',
  GAMES: 'tahadi5_games_v1',
  CURRENT_MATCH: 'tahadi5_current_match_v1',
  MATCHES_HISTORY: 'tahadi5_matches_history_v1',
  SELECTED_CATEGORIES: 'tahadi5_selected_categories_v1',
  CARD_STATES: 'tahadi5_card_states_v1',
  TIMER_SYNC: 'tahadi5_timer_sync_v1',
  ARENA_COLUMN_GAMES: 'tahadi5_arena_column_games_v1',
};

// Cross-tab broadcast channel for multi-monitor support
let broadcastChannel: BroadcastChannel | null = null;
if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
  try {
    broadcastChannel = new BroadcastChannel('tahadi_5_channel');
  } catch {
    broadcastChannel = null;
  }
}

export function broadcastMessage(type: string, payload: unknown) {
  if (broadcastChannel) {
    try {
      broadcastChannel.postMessage({ type, payload, timestamp: Date.now() });
    } catch {}
  }
}

export function subscribeToBroadcast(handler: (type: string, payload: unknown) => void): () => void {
  if (!broadcastChannel) return () => {};
  const listener = (event: MessageEvent) => {
    if (event.data && event.data.type) {
      handler(event.data.type, event.data.payload);
    }
  };
  broadcastChannel.addEventListener('message', listener);
  return () => {
    broadcastChannel?.removeEventListener('message', listener);
  };
}

// Teams
export function loadTeams(): Team[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TEAMS);
    if (raw) return JSON.parse(raw);
  } catch {}
  saveTeams(INITIAL_TEAMS);
  return INITIAL_TEAMS;
}

export function saveTeams(teams: Team[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.TEAMS, JSON.stringify(teams));
    broadcastMessage('TEAMS_UPDATED', teams);
  } catch {}
}

// Games library
export function loadGames(): GameItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.GAMES);
    if (raw) return JSON.parse(raw);
  } catch {}
  saveGames(DEFAULT_GAMES);
  return DEFAULT_GAMES;
}

export function saveGames(games: GameItem[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.GAMES, JSON.stringify(games));
    broadcastMessage('GAMES_UPDATED', games);
  } catch {}
}

// Selected categories for match (5 categories)
export function loadSelectedCategories(): CategoryKey[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SELECTED_CATEGORIES);
    if (raw) {
      const parsed: CategoryKey[] = JSON.parse(raw);
      // Migrate legacy 'captains' to 'fan_vote'
      const migrated = parsed.map((c) => (c === 'captains' ? 'fan_vote' : c));
      if (migrated.length >= 5) return migrated;
      // Ensure all 5 categories are included
      const allFive: CategoryKey[] = ['digital', 'mental', 'physical', '1v1', 'fan_vote'];
      return allFive;
    }
  } catch {}
  const initial: CategoryKey[] = ['digital', 'mental', 'physical', '1v1', 'fan_vote'];
  saveSelectedCategories(initial);
  return initial;
}

export function saveSelectedCategories(categories: CategoryKey[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.SELECTED_CATEGORIES, JSON.stringify(categories));
    broadcastMessage('CATEGORIES_UPDATED', categories);
  } catch {}
}

// Current Match
export function loadCurrentMatch(teams: Team[]): CurrentMatch {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_MATCH);
    if (raw) return JSON.parse(raw);
  } catch {}
  const initial: CurrentMatch = {
    teamAId: teams[0]?.id || 'team-1',
    teamBId: teams[1]?.id || 'team-2',
    teamAScore: 0,
    teamBScore: 0,
    activeGameId: null,
    currentRound: 1,
    rounds: [],
  };
  saveCurrentMatch(initial);
  return initial;
}

export function saveCurrentMatch(match: CurrentMatch) {
  try {
    localStorage.setItem(STORAGE_KEYS.CURRENT_MATCH, JSON.stringify(match));
    broadcastMessage('MATCH_UPDATED', match);
  } catch {}
}

// Matches History
export function loadMatchesHistory(): MatchRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.MATCHES_HISTORY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

export function saveMatchesHistory(matches: MatchRecord[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.MATCHES_HISTORY, JSON.stringify(matches));
    broadcastMessage('HISTORY_UPDATED', matches);
  } catch {}
}

// Card ban/pick states
export function loadCardStates(): Record<string, CardState> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CARD_STATES);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {};
}

export function saveCardStates(states: Record<string, CardState>) {
  try {
    localStorage.setItem(STORAGE_KEYS.CARD_STATES, JSON.stringify(states));
    broadcastMessage('CARDS_UPDATED', states);
  } catch {}
}

// Timer Sync
export function saveTimerSync(state: DualTimerSyncState) {
  try {
    localStorage.setItem(STORAGE_KEYS.TIMER_SYNC, JSON.stringify(state));
    broadcastMessage('TIMER_SYNC', state);
  } catch {}
}

export function loadTimerSync(): DualTimerSyncState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TIMER_SYNC);
    if (raw) return JSON.parse(raw);
  } catch {}
  return null;
}

// Compute League Standings based on completed match history
export function computeStandings(teams: Team[], matches: MatchRecord[]): LeagueRow[] {
  const map: Record<string, LeagueRow> = {};

  teams.forEach((t) => {
    map[t.id] = {
      teamId: t.id,
      team: t,
      played: 0,
      won: 0,
      lost: 0,
      gf: 0,
      ga: 0,
      gd: 0,
      points: 0,
      form: [],
    };
  });

  // Sort matches chronologically to track form
  const sortedMatches = [...matches].sort((a, b) => a.timestamp - b.timestamp);

  sortedMatches.forEach((m) => {
    const rowA = map[m.teamAId];
    const rowB = map[m.teamBId];

    if (rowA && rowB) {
      rowA.played += 1;
      rowB.played += 1;

      rowA.gf += m.teamAScore;
      rowA.ga += m.teamBScore;
      rowB.gf += m.teamBScore;
      rowB.ga += m.teamAScore;

      if (m.teamAScore > m.teamBScore) {
        rowA.won += 1;
        rowA.points += 3;
        rowA.form.push('W');

        rowB.lost += 1;
        rowB.form.push('L');
      } else if (m.teamBScore > m.teamAScore) {
        rowB.won += 1;
        rowB.points += 3;
        rowB.form.push('W');

        rowA.lost += 1;
        rowA.form.push('L');
      }
    }
  });

  // Calculate goal/round differences
  Object.values(map).forEach((r) => {
    r.gd = r.gf - r.ga;
    // Keep last 5 matches for form
    r.form = r.form.slice(-5);
  });

  // Sort by Points DESC -> GD DESC -> GF DESC -> Won DESC
  return Object.values(map).sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.gd !== a.gd) return b.gd - a.gd;
    if (b.gf !== a.gf) return b.gf - a.gf;
    return b.won - a.won;
  });
}

export const DEFAULT_ARENA_COLUMN_GAMES: Record<string, string[]> = {
  digital: ['g-tricky-towers', 'g-overcooked-2', 'g-crash-team-racing'],
  mental: ['g-photo-match', 'g-who-am-i', 'g-letters-game'],
  physical: ['g-basketball', 'g-strength-tester', 'g-penalty-shoot'],
  '1v1': ['g-fatal-fury', 'g-throw-challenge', 'g-fc27-1v1'],
  fan_vote: ['g-box-of-liars', 'g-stop-timer', 'g-clash-royale'],
};

export function loadArenaColumnGames(): Record<string, string[]> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ARENA_COLUMN_GAMES);
    if (raw) return JSON.parse(raw);
  } catch {}
  return DEFAULT_ARENA_COLUMN_GAMES;
}

export function saveArenaColumnGames(gamesMap: Record<string, string[]>) {
  try {
    localStorage.setItem(STORAGE_KEYS.ARENA_COLUMN_GAMES, JSON.stringify(gamesMap));
    broadcastMessage('ARENA_GAMES_UPDATED', gamesMap);
  } catch {}
}
