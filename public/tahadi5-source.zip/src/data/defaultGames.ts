import { CategoryInfo, GameItem, Team } from '../types';

export const INITIAL_TEAMS: Team[] = [
  {
    id: 'team-1',
    name: 'أبو شنيف',
    shortName: 'ABO SHAIF',
    color: '#A855F7', // Violet / Purple
    bgBadge: 'from-purple-600/30 to-purple-900/40 border-purple-500/60',
    logo: 'crown',
  },
  {
    id: 'team-2',
    name: 'يزيد',
    shortName: 'YAZEED',
    color: '#06B6D4', // Cyan
    bgBadge: 'from-cyan-600/30 to-cyan-900/40 border-cyan-500/60',
    logo: 'shield',
  },
  {
    id: 'team-3',
    name: 'بندريتا',
    shortName: 'BANDARITA',
    color: '#10B981', // Emerald
    bgBadge: 'from-emerald-600/30 to-emerald-900/40 border-emerald-500/60',
    logo: 'zap',
  },
  {
    id: 'team-4',
    name: 'فهد سال',
    shortName: 'FAHAD SAL',
    color: '#F59E0B', // Amber
    bgBadge: 'from-amber-600/30 to-amber-900/40 border-amber-500/60',
    logo: 'flame',
  },
  {
    id: 'team-5',
    name: 'مروان',
    shortName: 'MARWAN',
    color: '#F43F5E', // Rose
    bgBadge: 'from-rose-600/30 to-rose-900/40 border-rose-500/60',
    logo: 'swords',
  },
  {
    id: 'team-6',
    name: 'عزيز',
    shortName: 'AZIZ',
    color: '#3B82F6', // Blue
    bgBadge: 'from-blue-600/30 to-blue-900/40 border-blue-500/60',
    logo: 'target',
  },
];

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'digital',
    nameAr: 'إلكتروني',
    nameEn: 'DIGITAL',
    description: 'ألعاب الفيديو والشاشات والأجهزة الإلكترونية',
    accentColor: '#38BDF8', // Cyan
    glowColor: 'rgba(56, 189, 248, 0.4)',
    icon: 'gamepad',
  },
  {
    id: 'mental',
    nameAr: 'ذكاء',
    nameEn: 'MENTAL',
    description: 'تحديات التفكير والذاكرة والألغاز وسرعة البديهة',
    accentColor: '#C084FC', // Purple
    glowColor: 'rgba(192, 132, 252, 0.4)',
    icon: 'brain',
  },
  {
    id: 'physical',
    nameAr: 'بدني',
    nameEn: 'PHYSICAL',
    description: 'تحديات الحركة واللياقة والتسديد والموازنة',
    accentColor: '#FB923C', // Orange
    glowColor: 'rgba(251, 146, 60, 0.4)',
    icon: 'activity',
  },
  {
    id: '1v1',
    nameAr: 'مواجهة 1 ضد 1',
    nameEn: '1V1 DUEL',
    description: 'مواجهات فردية مباشرة بين لاعبي الفريقين',
    accentColor: '#F43F5E', // Rose
    glowColor: 'rgba(244, 63, 94, 0.4)',
    icon: 'swords',
  },
  {
    id: 'fan_vote',
    nameAr: 'تصويت الجماهير',
    nameEn: 'FAN VOTE',
    description: 'تصويت الجمهور المباشر لاختيار أي لعبة من كامل مكتبة الألعاب',
    accentColor: '#EC4899', // Pink / Magenta
    glowColor: 'rgba(236, 72, 153, 0.4)',
    icon: 'flame',
  },
];

export const DEFAULT_GAMES: GameItem[] = [
  // DIGITAL
  {
    id: 'g-fc27',
    categoryId: 'digital',
    nameAr: 'إف سي 27',
    nameEn: 'EA FC 27',
    description: 'مباراة كرة قدم إلكترونية حماسية',
    iconType: 'fc27',
  },
  {
    id: 'g-clash-royale',
    categoryId: 'digital',
    nameAr: 'كلاش رويال',
    nameEn: 'CLASH ROYALE',
    description: 'معركة بطاقات واستراتيجية سريعة',
    iconType: 'clash',
  },
  {
    id: 'g-rocket-league',
    categoryId: 'digital',
    nameAr: 'روكيت ليج',
    nameEn: 'ROCKET LEAGUE',
    description: 'كرة قدم بسيارات الصواريخ الطائرة',
    iconType: 'rocket',
  },
  {
    id: 'g-brawlhalla',
    categoryId: 'digital',
    nameAr: 'براول هالا',
    nameEn: 'BRAWLHALLA',
    description: 'نزال جماعي لإسقاط الخصوم من حلبة القتال',
    iconType: 'brawlhalla',
  },
  {
    id: 'g-sackboy',
    categoryId: 'digital',
    nameAr: 'ساكبوي 4',
    nameEn: 'SACKBOY 4',
    description: 'مغامرة قفز وألغاز وتعاون جماعي',
    iconType: 'sackboy',
  },
  {
    id: 'g-overcooked-2',
    categoryId: 'digital',
    nameAr: 'أوفر كوكد',
    nameEn: 'OVERCOOKED!',
    description: 'إعداد وجبات سريعة في مطبخ فوضوي مشترك',
    iconType: 'chef',
  },
  {
    id: 'g-screamer',
    categoryId: 'digital',
    nameAr: 'سكريمير',
    nameEn: 'SCREAMER',
    description: 'تحدي الرعب وردة الفعل الصامتة',
    iconType: 'screamer',
  },
  {
    id: 'g-tekken-8',
    categoryId: 'digital',
    nameAr: 'تيكن 8',
    nameEn: 'TEKKEN 8',
    description: 'قتال قتالي كلاسيكي حماسي 1 ضد 1',
    iconType: 'tekken',
  },
  {
    id: 'g-tricky-towers',
    categoryId: 'digital',
    nameAr: 'تريكي تاورز',
    nameEn: 'TRICKY TOWERS',
    description: 'بناء برج من القطع الهندسية دون أن يسقط',
    iconType: 'tower',
  },
  {
    id: 'g-crash-team-racing',
    categoryId: 'digital',
    nameAr: 'كراش تيم ريسنج',
    nameEn: 'CRASH TEAM RACING',
    description: 'سباق سيارات ممتع وسريع بين المتسابقين',
    iconType: 'racing',
  },

  // MENTAL
  {
    id: 'g-photo-match',
    categoryId: 'mental',
    nameAr: 'تطابق الصور',
    nameEn: 'IMAGE MATCH',
    description: 'اكتشاف وتطابق أزواج الصور بأسرع وقت',
    iconType: 'brain',
  },
  {
    id: 'g-who-am-i',
    categoryId: 'mental',
    nameAr: 'من أكون؟',
    nameEn: 'WHO AM I?',
    description: 'تخمين الشخصية أو الشيء عبر أسئلة محددة',
    iconType: 'spy',
  },
  {
    id: 'g-letters-game',
    categoryId: 'mental',
    nameAr: 'لعبة الحروف (مع عزيز)',
    nameEn: 'LETTERS GAME',
    description: 'توليد كلمات وفق حروف وشروط مباغتة',
    iconType: 'hats',
  },
  {
    id: 'g-codenames',
    categoryId: 'mental',
    nameAr: 'كود نيمز',
    nameEn: 'CODENAMES',
    description: 'تخمين الكلمات السرية للفريق برمز واحد',
    iconType: 'cards',
  },
  {
    id: 'g-shans',
    categoryId: 'mental',
    nameAr: 'شَنْص',
    nameEn: 'SHANS',
    description: 'تحدي الحظ والقرارات الاستراتيجية السريعة',
    iconType: 'dice',
  },
  {
    id: 'g-seen-jeem',
    categoryId: 'mental',
    nameAr: 'حرف وجواب (ج)',
    nameEn: 'Q & A SPEED',
    description: 'إجابة سريعة على أسئلة ثقافية تبدأ بالحرف المطلوب',
    iconType: 'quiz',
  },
  {
    id: 'g-kalak',
    categoryId: 'mental',
    nameAr: 'كلك',
    nameEn: 'KALAK',
    description: 'تحدي المهارة الحركية والتركيز الذهني',
    iconType: 'kalak',
  },

  // PHYSICAL
  {
    id: 'g-basketball',
    categoryId: 'physical',
    nameAr: 'كرة سلة',
    nameEn: 'BASKETBALL',
    description: 'تسديد الكرات في السلة وتسجيل أعلى رصيد',
    iconType: 'basketball',
  },
  {
    id: 'g-strength-tester',
    categoryId: 'physical',
    nameAr: 'اختبار القوة',
    nameEn: 'STRENGTH TESTER',
    description: 'قياس قوة الضربة أو الرفعة وسحق الأرقام',
    iconType: 'trophy',
  },
  {
    id: 'g-penalty-shoot',
    categoryId: 'physical',
    nameAr: 'ركلات جزاء',
    nameEn: 'PENALTY SHOOT',
    description: 'تسديد ركلات جزاء دقيقة نحو نقاط الهدف',
    iconType: 'penalty',
  },
  {
    id: 'g-football-2v2',
    categoryId: 'physical',
    nameAr: 'كرة قدم 2v2',
    nameEn: 'FOOTBALL 2v2',
    description: 'مواجهة ميدانية ثنائية سريعة بالمرمى الصغير',
    iconType: 'football',
  },
  {
    id: 'g-bottle-flip-xo',
    categoryId: 'physical',
    nameAr: 'قلب الزجاجة / XO',
    nameEn: 'BOTTLE FLIP XO',
    description: 'قلب الزجاجة لتثبيتها ولعب حركة في شبكة XO',
    iconType: 'bottle',
  },
  {
    id: 'g-hawks-eagle',
    categoryId: 'physical',
    nameAr: 'صقور ونسر',
    nameEn: 'HAWKS & EAGLE',
    description: 'مطاردة حركية وتفادي سريع بالملعب',
    iconType: 'eagle',
  },
  {
    id: 'g-cap-ball',
    categoryId: 'physical',
    nameAr: 'طاقية بالكرة',
    nameEn: 'CAP & BALL',
    description: 'التقاط الكرة بالغطاء أو توجيهها بمهارة توازن',
    iconType: 'cap',
  },

  // 1V1
  {
    id: 'g-fatal-fury',
    categoryId: '1v1',
    nameAr: 'فاتال فيوري',
    nameEn: 'FATAL FURY',
    description: 'مواجهة قتالية مشتعلة وجهاً لوجه',
    iconType: 'fighter',
  },
  {
    id: 'g-throw-challenge',
    categoryId: '1v1',
    nameAr: 'تحدي الرمي (أكياس الرمل)',
    nameEn: 'CORNHOLE TOSS',
    description: 'رمي الأكياس بدقة نحو فتحة اللوح المائل',
    iconType: 'sack',
  },
  {
    id: 'g-fc27-1v1',
    categoryId: '1v1',
    nameAr: 'إف سي 27 (1 ضد 1)',
    nameEn: 'EA FC 27 1V1',
    description: 'مباراة شوط واحد ذهبي بين ممثلَي الفريقين',
    iconType: 'fc27',
  },

  // FAN VOTE (تصويت الجماهير - متاح كامل ألعاب المكتبة)
  {
    id: 'g-box-of-liars',
    categoryId: 'fan_vote',
    nameAr: 'صندوق الكذابين',
    nameEn: 'BOX OF LIARS',
    description: 'وصف ما بداخل الصندوق واكتشاف إن كان يصدق أم يراوغ',
    iconType: 'box',
  },
  {
    id: 'g-stop-timer',
    categoryId: 'fan_vote',
    nameAr: 'وقف المؤقت بالثانية',
    nameEn: 'STOP THE TIMER',
    description: 'إيقاف ساعة التوقيت بدقة متناهية دون النظر للشاشة',
    iconType: 'timer',
  },
  {
    id: 'g-fan-wildcard',
    categoryId: 'fan_vote',
    nameAr: 'اختيار الجماهير الحر',
    nameEn: 'FAN WILDCARD',
    description: 'أي لعبة تختارها الجماهير من كامل مكتبة الألعاب',
    iconType: 'flame',
  },
];
